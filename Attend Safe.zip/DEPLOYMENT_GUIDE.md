# AttendSafe — Firebase Setup & Play Store Deployment Guide
### Created by Ratnasanu Ghosh

---

## 📁 Project File Structure

```
AttendSafe/
├── index.html        ← Main PWA app (all UI + logic)
├── sw.js             ← Service Worker (offline + caching)
├── manifest.json     ← PWA manifest (name, icons, theme)
├── offline.html      ← Offline fallback page
├── icons/            ← App icons (you must generate these)
│   ├── icon-72.png
│   ├── icon-96.png
│   ├── icon-128.png
│   ├── icon-144.png
│   ├── icon-152.png
│   ├── icon-192.png  ← Required for PWA install
│   ├── icon-384.png
│   └── icon-512.png  ← Required for Play Store
└── screenshots/
    ├── desktop.png   ← 1280×800
    └── mobile.png    ← 390×844
```

---

## 🔥 STEP 1 — Set Up Firebase

### 1.1 Create Firebase Project
1. Go to https://console.firebase.google.com
2. Click **"Add project"** → name it `attendsafe`
3. Disable Google Analytics (optional for now)

### 1.2 Enable Firebase Authentication
1. In Firebase Console → **Build → Authentication**
2. Click **"Get started"**
3. Enable **Email/Password** provider
4. Add your admin user:
   - Email: `admin@yourcompany.com`
   - Password: (strong password — min 8 chars, uppercase, number, symbol)

### 1.3 Enable Firestore Database
1. **Build → Firestore Database → Create database**
2. Start in **production mode**
3. Set security rules (see below)

### 1.4 Firestore Security Rules
```
rules_version = '2';
service cloud.firestore {
  match /databases/{database}/documents {
    // Only authenticated users can read/write
    match /employees/{doc} {
      allow read, write: if request.auth != null;
    }
    match /attendance/{doc} {
      allow read, write: if request.auth != null;
    }
    match /appointments/{doc} {
      allow read, write: if request.auth != null;
    }
  }
}
```

### 1.5 Get Firebase Config
1. Firebase Console → Project Settings (⚙️) → **Your apps → Web app**
2. Copy the config object — it looks like:
```javascript
const firebaseConfig = {
  apiKey:            "AIzaSy...",
  authDomain:        "attendsafe.firebaseapp.com",
  projectId:         "attendsafe",
  storageBucket:     "attendsafe.appspot.com",
  messagingSenderId: "1234567890",
  appId:             "1:1234567890:web:abc123"
};
```

### 1.6 Replace Demo Auth in index.html
Find the comment `// PRODUCTION: Replace doLogin() with Firebase Authentication:`
and replace the `doLogin()` function body with:

```javascript
import { initializeApp }        from "https://www.gstatic.com/firebasejs/10.x.x/firebase-app.js";
import { getAuth, signInWithEmailAndPassword, signOut } from "https://www.gstatic.com/firebasejs/10.x.x/firebase-auth.js";

const app  = initializeApp(firebaseConfig);
const auth = getAuth(app);

function doLogin() {
  var email    = document.getElementById('l-user').value.trim();
  var password = document.getElementById('l-pass').value;
  signInWithEmailAndPassword(auth, email, password)
    .then((cred) => {
      // Firebase handles tokens, session, expiry
      document.getElementById('login-screen').style.display = 'none';
      document.getElementById('main-app').style.display = '';
      document.getElementById('l-pass').value = '';
    })
    .catch((error) => {
      // Firebase error codes: auth/wrong-password, auth/user-not-found, etc.
      document.getElementById('login-err').style.display = '';
    });
}

function doLogout() {
  signOut(auth).then(() => {
    document.getElementById('main-app').style.display = 'none';
    document.getElementById('login-screen').style.display = 'flex';
  });
}
```

---

## 🌐 STEP 2 — Deploy to Firebase Hosting

### 2.1 Install Firebase CLI
```bash
npm install -g firebase-tools
firebase login
```

### 2.2 Initialize Hosting
```bash
cd AttendSafe/
firebase init hosting
```
- Select your project: `attendsafe`
- Public directory: `.` (current folder)
- Configure as SPA: **Yes**
- Overwrite index.html: **No**

### 2.3 Add Security Headers (firebase.json)
```json
{
  "hosting": {
    "public": ".",
    "ignore": ["firebase.json", "**/.*", "**/node_modules/**"],
    "rewrites": [{ "source": "**", "destination": "/index.html" }],
    "headers": [
      {
        "source": "**",
        "headers": [
          { "key": "Strict-Transport-Security",    "value": "max-age=31536000; includeSubDomains; preload" },
          { "key": "X-Content-Type-Options",        "value": "nosniff" },
          { "key": "X-Frame-Options",               "value": "DENY" },
          { "key": "X-XSS-Protection",              "value": "1; mode=block" },
          { "key": "Referrer-Policy",               "value": "strict-origin-when-cross-origin" },
          { "key": "Permissions-Policy",            "value": "camera=(), microphone=(), geolocation=()" },
          { "key": "Content-Security-Policy",       "value": "default-src 'self'; script-src 'self' 'unsafe-inline' https://cdnjs.cloudflare.com https://www.gstatic.com; style-src 'self' 'unsafe-inline' https://fonts.googleapis.com https://cdnjs.cloudflare.com; font-src https://fonts.gstatic.com https://cdnjs.cloudflare.com; connect-src 'self' https://*.firebaseio.com https://*.googleapis.com; img-src 'self' data:;" }
        ]
      }
    ]
  }
}
```

### 2.4 Deploy
```bash
firebase deploy --only hosting
```
Your app will be live at: `https://attendsafe.web.app`

---

## 📱 STEP 3 — Publish to Google Play Store via PWABuilder

> No Android coding needed — PWABuilder wraps your PWA into an APK.

### 3.1 Generate App Icons
Use https://realfavicongenerator.net or https://maskable.app/editor
- Upload a 512×512 PNG of your logo
- Download all sizes and place in `/icons/`

### 3.2 Use PWABuilder
1. Go to https://www.pwabuilder.com
2. Enter your deployed URL: `https://attendsafe.web.app`
3. Click **"Build My PWA"**
4. Select **Android** → Download the `.aab` package
5. PWABuilder will warn you if anything in the manifest is missing

### 3.3 Sign the APK
```bash
# Generate a keystore (do this ONCE and keep it safe forever)
keytool -genkey -v \
  -keystore attendsafe-release.jks \
  -keyalg RSA -keysize 2048 \
  -validity 10000 \
  -alias attendsafe

# Sign the bundle
jarsigner -verbose -sigalg SHA256withRSA -digestalg SHA-256 \
  -keystore attendsafe-release.jks \
  app-release.aab attendsafe
```

⚠️  **CRITICAL**: Back up `attendsafe-release.jks` — losing it means you can NEVER update the app.

### 3.4 Create Google Play Developer Account
1. Go to https://play.google.com/console
2. Pay the one-time $25 USD registration fee
3. Complete identity verification

### 3.5 Submit the App
1. Create new app → name: "AttendSafe"
2. Upload your signed `.aab`
3. Fill in: description, screenshots, content rating
4. Set up **internal testing** → test for 14 days (Google requirement)
5. Apply for **production release**

---

## 🔒 STEP 4 — Security Checklist Before Publishing

- [x] No hardcoded credentials in code (remove demo hint before deploy)
- [x] Firebase Authentication (not client-side password check)
- [x] Firestore security rules (authenticated reads/writes only)
- [x] HTTPS enforced (Firebase Hosting does this automatically)
- [x] Security headers via firebase.json
- [x] Input sanitization in all form fields
- [x] Rate limiting on login (5 attempts → 30s lockout)
- [x] Session tokens cleared on logout
- [x] Password field cleared from DOM after login
- [x] Service Worker caches only safe static assets
- [ ] Enable Firebase App Check (protects backend from abuse)
- [ ] Enable Firebase MFA for admin accounts
- [ ] Set up Firebase Alerts for suspicious login activity
- [ ] Run Lighthouse audit (aim for PWA score ≥ 90)
- [ ] Test with https://www.ssllabs.com/ssltest/

### Firebase App Check (add to index.html)
```javascript
import { initializeAppCheck, ReCaptchaV3Provider } from "firebase/app-check";
initializeAppCheck(app, {
  provider: new ReCaptchaV3Provider('YOUR_RECAPTCHA_SITE_KEY'),
  isTokenAutoRefreshEnabled: true
});
```

---

## 📊 STEP 5 — Lighthouse PWA Audit

Run this before submitting to Play Store:
```bash
npx lighthouse https://attendsafe.web.app \
  --only-categories=pwa,performance,accessibility,best-practices \
  --output=html --output-path=./lighthouse-report.html
```

Target scores:
- PWA:            100 ✅
- Performance:    ≥ 90
- Accessibility:  ≥ 95
- Best Practices: ≥ 95

---

## 💰 Cost Summary

| Service              | Cost         |
|----------------------|--------------|
| Firebase Hosting     | Free (10GB/month) |
| Firebase Auth        | Free (up to 10K users/month) |
| Firestore            | Free (1GB storage, 50K reads/day) |
| Google Play Dev Acc  | $25 one-time |
| Domain (optional)    | ~$12/year    |
| **Total to launch**  | **~$25 USD** |

---

## 📞 Support & Next Steps

- Firebase Docs:   https://firebase.google.com/docs
- PWABuilder:      https://docs.pwabuilder.com
- Play Console:    https://support.google.com/googleplay/android-developer
- Lighthouse:      https://developer.chrome.com/docs/lighthouse

---
*AttendSafe PWA — Built for secure, Play Store-ready deployment*
*Author: Ratnasanu Ghosh*
