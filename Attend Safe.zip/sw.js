/* AttendSafe Service Worker — v1.0.0
   Caches app shell for offline use.
   In production: update CACHE_NAME to bust cache on deploy. */

'use strict';

const CACHE_NAME    = 'attendsafe-v1.0.0';
const OFFLINE_URL   = '/offline.html';

// App Shell — files to cache immediately on install
const APP_SHELL = [
  '/',
  '/index.html',
  '/manifest.json',
  '/offline.html',
  'https://cdnjs.cloudflare.com/ajax/libs/Chart.js/4.4.1/chart.umd.js',
  'https://cdnjs.cloudflare.com/ajax/libs/tabler-icons/3.19.0/fonts/tabler-icons.min.css',
  'https://fonts.googleapis.com/css2?family=Syne:wght@400;500;600;700&family=IBM+Plex+Mono:wght@400;500&display=swap',
];

// ── INSTALL: Cache app shell ────────────────────────────────────────────
self.addEventListener('install', function(event) {
  console.log('[SW] Installing AttendSafe v1.0.0');
  event.waitUntil(
    caches.open(CACHE_NAME)
      .then(function(cache) {
        console.log('[SW] Caching app shell');
        // Cache what we can; don't fail on cross-origin issues
        return Promise.allSettled(
          APP_SHELL.map(function(url) { return cache.add(url).catch(function(e){ console.warn('[SW] Failed to cache:', url, e); }); })
        );
      })
      .then(function() { return self.skipWaiting(); })
  );
});

// ── ACTIVATE: Remove old caches ────────────────────────────────────────
self.addEventListener('activate', function(event) {
  console.log('[SW] Activating — clearing old caches');
  event.waitUntil(
    caches.keys().then(function(keys) {
      return Promise.all(
        keys.filter(function(k) { return k !== CACHE_NAME; })
            .map(function(k) { console.log('[SW] Deleting cache:', k); return caches.delete(k); })
      );
    }).then(function() { return self.clients.claim(); })
  );
});

// ── FETCH: Cache-first for assets, network-first for API/data ──────────
self.addEventListener('fetch', function(event) {
  var req = event.request;

  // Only handle GET requests
  if (req.method !== 'GET') return;

  // Skip Chrome extensions and non-http(s)
  if (!req.url.startsWith('http')) return;

  // Firebase API calls: network-first, fall back to cache
  if (req.url.includes('firebaseio.com') || req.url.includes('googleapis.com/identitytoolkit')) {
    event.respondWith(networkFirst(req));
    return;
  }

  // App shell & static assets: cache-first
  event.respondWith(cacheFirst(req));
});

function cacheFirst(req) {
  return caches.match(req).then(function(cached) {
    if (cached) return cached;
    return fetch(req).then(function(response) {
      if (!response || response.status !== 200 || response.type === 'opaque') return response;
      var clone = response.clone();
      caches.open(CACHE_NAME).then(function(c) { c.put(req, clone); });
      return response;
    }).catch(function() {
      // Return offline page for navigation requests
      if (req.mode === 'navigate') return caches.match(OFFLINE_URL);
    });
  });
}

function networkFirst(req) {
  return fetch(req).then(function(response) {
    if (!response || response.status !== 200) return response;
    var clone = response.clone();
    caches.open(CACHE_NAME).then(function(c) { c.put(req, clone); });
    return response;
  }).catch(function() {
    return caches.match(req);
  });
}

// ── BACKGROUND SYNC (for offline attendance writes) ────────────────────
// Register with: navigator.serviceWorker.ready.then(sw => sw.sync.register('sync-attendance'))
self.addEventListener('sync', function(event) {
  if (event.tag === 'sync-attendance') {
    console.log('[SW] Background sync: uploading pending attendance records');
    event.waitUntil(syncPendingRecords());
  }
});

async function syncPendingRecords() {
  // In production: read from IndexedDB, POST to Firebase, then clear
  // const db = await openIndexedDB();
  // const records = await db.getAll('pending-attendance');
  // await Promise.all(records.map(r => uploadToFirebase(r)));
  console.log('[SW] Sync complete (stub — implement with IndexedDB + Firebase)');
}

// ── PUSH NOTIFICATIONS (optional) ─────────────────────────────────────
self.addEventListener('push', function(event) {
  if (!event.data) return;
  var data = event.data.json();
  event.waitUntil(
    self.registration.showNotification(data.title || 'AttendSafe', {
      body:    data.body    || 'You have a new notification.',
      icon:    '/icons/icon-192.png',
      badge:   '/icons/badge-72.png',
      vibrate: [100, 50, 100],
      data:    { url: data.url || '/' },
      actions: [
        { action: 'view',    title: 'View' },
        { action: 'dismiss', title: 'Dismiss' }
      ]
    })
  );
});

self.addEventListener('notificationclick', function(event) {
  event.notification.close();
  if (event.action === 'dismiss') return;
  event.waitUntil(
    clients.matchAll({ type:'window', includeUncontrolled:true }).then(function(cls) {
      var url = event.notification.data.url || '/';
      for (var c of cls) {
        if (c.url === url && 'focus' in c) return c.focus();
      }
      if (clients.openWindow) return clients.openWindow(url);
    })
  );
});
